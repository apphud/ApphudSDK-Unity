using System;
using System.Collections.Generic;
using Apphud.Unity.Common;
using Apphud.Unity.Domain;

#if UNITY_EDITOR
using Apphud.Unity.Editor;
#elif UNITY_ANDROID
using Apphud.Unity.Android.SDK;
#elif UNITY_IOS
using Apphud.Unity.IOS.SDK;
#endif

namespace Apphud.Unity.SDK
{
    public static class ApphudSDK
    {
#if UNITY_EDITOR
        private static readonly IApphudSDK _sdk = new ApphudEditorSDK();
#elif UNITY_ANDROID
        private static readonly IApphudSDK _sdk = new ApphudAndroidSDK();
#elif UNITY_IOS
        private static readonly IApphudSDK _sdk = new ApphudIOSSDK();
#endif

        /// <summary>
        /// Retrieves the current user ID that identifies the user across multiple devices.
        /// </summary>
        public static string UserId => _sdk.UserId;

        /// <summary>
        /// Retrieves the current device ID. This is useful if you want to implement
        /// a custom logout/login flow by saving the User ID and Device ID pair for each app user.
        /// </summary>
        public static string DeviceId => _sdk.DeviceId;

        /// <summary>
        /// Initializes the Apphud SDK. This method should be called during the app launch.
        /// </summary>
        /// <param name="apiKey">Your API key. This is a required parameter.</param>
        /// <param name="observerMode">
        /// Optional. Sets SDK to Observer (Analytics) mode.
        /// If you purchase products by your own code, then pass `true`. 
        /// If you purchase products using `Apphud.purchase(product)` method, then pass `false`.
        /// Default value is `false`.
        /// </param>
        /// <param name="callback">(Optional) A callback function that is invoked with the `ApphudUser` object after the SDK initialization is complete. 
        /// __Note__: Do not store `ApphudUser`instance in your own code, since it may change at runtime.
        /// </param>
        public static void Start(string apiKey, Action<ApphudUser> callback, bool observerMode = false) => _sdk.Start(apiKey, callback, observerMode);

        /// <summary>
        /// Initializes the Apphud SDK. This method should be called during the app launch.
        /// </summary>
        /// <param name="apiKey">Your API key. This is a required parameter.</param>
        /// <param name="userId">(Optional) A unique user identifier. If null is passed, a UUID will be generated and used as the user identifier.</param>
        /// <param name="observerMode">
        /// Optional. Sets SDK to Observer (Analytics) mode.
        /// If you purchase products by your own code, then pass `true`. 
        /// If you purchase products using `Apphud.purchase(product)` method, then pass `false`.
        /// Default value is `false`.
        /// </param>
        /// <param name="callback">(Optional) A callback function that is invoked with the `ApphudUser` object after the SDK initialization is complete. 
        /// __Note__: Do not store `ApphudUser`instance in your own code, since it may change at runtime.
        /// </param>
        public static void Start(string apiKey, string userId, Action<ApphudUser> callback, bool observerMode = false) => _sdk.Start(apiKey, userId, callback, observerMode);

        /// <summary>
        /// Disables automatic paywall and placement requests during the SDK's initial setup.
        /// Developers must explicitly call `FetchPlacements` method at a later point in the app's lifecycle to fetch placements with inner paywalls.
        /// </summary>
        public static void DeferPlacements() => _sdk.DeferPlacements();

        /// <summary>
        /// This method sends all user properties immediately to Apphud.
        /// Should be used for audience segmentation in placements based on user properties.
        /// </summary>
        public static void ForceFlushUserProperties(Action<bool> completion) => _sdk.ForceFlushUserProperties(completion);


        /// <summary>
        /// Use this method if you have a custom login system with your own backend logic.
        /// It effectively logs out the current user in the context of the Apphud SDK.
        /// </summary>
        public static void LogOut() => _sdk.LogOut();

        /// <summary>
        /// Updates the user ID. Use this when you need to change the user identifier during the app's runtime.
        ///
        /// [Android] This method should only be called after the user is registered,
        /// for example, inside the `ApphudListener.userDidLoad` callback.
        /// </summary>
        /// <param name="userId">Required. The new user ID value.</param>
        /// <param name="callback">
        /// Optional. A closure that gets called with the updated `ApphudUser` object.
        /// The user object may be `null` if user registering fails.
        /// </param>
        public static void UpdateUserId(string userId, Action<ApphudUser> callback = null) => _sdk.UpdateUserId(userId, callback);

        /// <summary>
        /// Retrieves the placements configured in Mission control &gt; Targetings, potentially altered
        /// based on the user's involvement in A/B testing, if any.
        ///
        /// Awaits until the inner `SKProduct`s (iOS) or `ProductDetails` (Android) are loaded
        /// from the App Store / Google Play.
        ///
        /// A placement is a specific location within a user's journey
        /// (such as onboarding, settings, etc.) where its internal paywall is intended to be displayed.
        /// See documentation for details: https://docs.apphud.com/docs/placements.
        ///
        /// __IMPORTANT:__ The callback may return both placements and an error simultaneously.
        /// If there is an issue with Google Billing or StoreKit and inner product details could not be fetched,
        /// an error will be returned along with the raw placements array.
        /// This allows for handling situations where partial data is available.
        /// </summary>
        /// <param name="callback">
        /// The callback function that is invoked with the list of `ApphudPlacement` objects.
        /// Second parameter in callback represents optional error, which may be on
        /// Google (BillingClient issue), App Store (StoreKit error), or Apphud side.
        /// </param>
        /// <param name="maxAttempts">
        /// [iOS] Number of request attempts before throwing an error. Must be between 1 and 10. Default value is 3.
        /// [Android] Ignored — Android uses a fixed `preferredTimeout` (the approximate duration, in seconds,
        /// after which the SDK ceases retry attempts to the Apphud backend; default and minimum is 10.0 seconds).
        /// </param>
        /// <param name="forceRefresh">
        /// When set to `true`, forces Apphud to refresh user data and reload placements from the server
        /// before returning the result. Use this when you need to apply updated audience segmentation or
        /// A/B test assignments (for example, after changing user properties that affect placement targeting).
        /// </param>
        public static void FetchPlacements(Action<List<ApphudPlacement>, ApphudError> callback, int maxAttempts = 3, bool forceRefresh = false) => _sdk.FetchPlacements(callback, maxAttempts, forceRefresh);

        /// <summary>
        /// Retrieves all the subscription objects that the user has ever purchased.
        /// The information is cached on the device.
        /// </summary>
        /// <returns>A list of `ApphudSubscription` objects.</returns>
        public static List<ApphudSubscription> Subscriptions() => _sdk.Subscriptions();

        /// <summary>
        /// Retrieves all non-renewing product purchases that the user has ever made.
        /// The information is cached on the device and sorted by purchase date.
        /// </summary>
        /// <returns>A list of `ApphudNonRenewingPurchase` objects.</returns>
        public static List<ApphudNonRenewingPurchase> NonRenewingPurchases() => _sdk.NonRenewingPurchases();

        /// <summary>
        /// Call this method when your paywall screen is displayed to the user.
        /// This is required for A/B testing analysis.
        /// </summary>
        /// <param name="paywall">The `ApphudPaywall` object representing the paywall shown to the user.</param>
        public static void PaywallShown(ApphudPaywall paywall) => _sdk.PaywallShown(paywall);

        /// <summary>
        /// Initiates the purchase process for a specified product and automatically
        /// submits the purchase token to Apphud.
        /// </summary>
        /// <param name="product">The `ApphudProduct` object representing the product to be purchased.</param>
        /// <param name="offerIdToken">[Android ONLY](Required for Subscriptions) The identifier of the offer for initiating the purchase.
        /// Developer should retrieve it from SubscriptionOfferDetails array.
        /// If not passed, then SDK will try to use first one from the array.
        /// </param>
        /// <param name="oldToken">[Android ONLY](Optional) The Google Play Billing purchase token that the user is upgrading or downgrading from.
        /// </param>
        /// <param name="replacementMode">
        /// [Android ONLY](Optional) The replacement mode for the subscription update.
        /// </param>
        /// <param name="consumableInAppProduct">
        /// [Android ONLY](Optional) Set to true for consumable products. Otherwise purchase will be treated as non-consumable and acknowledged.
        /// </param>
        /// <param name="callback">(Optional) A callback that returns an `ApphudPurchaseResult` object.</param>
        public static void Purchase(
            ApphudProduct product,
            string offerIdToken = null,
            string oldToken = null,
            int? replacementMode = null,
            bool consumableInAppProduct = false,
            Action<ApphudPurchaseResult> callback = null
        ) => _sdk.Purchase(product, offerIdToken, oldToken, replacementMode, consumableInAppProduct, callback);

        /// <summary>
        /// Implements the 'Restore Purchases' mechanism. 
        /// On Android this method sends the current Play Market Purchase Tokens to Apphud and returns subscription information.
        /// Note: Even if the callback returns some subscription, it doesn't necessarily mean that
        /// the subscription is active. Check `subscription.isActive()` for subscription status.
        /// </summary>
        /// <param name="callback">Required. A callback that returns the first active subscription, in-app product, or an optional error.</param>
        public static void RestorePurchases(Action<ApphudSubscription, ApphudNonRenewingPurchase, ApphudError> callback) => _sdk.RestorePurchases(callback);

        /// <summary>
        /// Grants a free promotional subscription to the user.
        /// Returns `true` in the callback if the promotional subscription was successfully granted.
        /// 
        /// Note: Either pass `productId` or `permissionGroup`, or pass both as null.
        /// If both are provided, `productId` will be used.
        /// </summary>
        /// <param name="daysCount">The number of days for the free premium access. For a lifetime promotion, pass a large number.</param>
        /// <param name="callback">(Optional) Returns `true` if the promotional subscription was granted.</param>
        public static void GrantPromotional(int daysCount, Action<bool> callback = null) => _sdk.GrantPromotional(daysCount, callback);

        /// <summary>
        /// Determines if the user has active premium access, which includes any active subscription or non-renewing purchase (lifetime).
        /// </summary>
        /// <returns>`true` if the user has an active subscription or non-renewing purchase, `false` otherwise.</returns>
        public static bool HasPremiumAccess() => _sdk.HasPremiumAccess();

        /// <summary>
        /// Checks if the user has an active subscription. The information is cached on the device.
        /// Use this method to determine whether the user has an active premium subscription.
        /// Note: If you offer lifetime purchases, you must use the `isNonRenewingPurchaseActive` method.
        /// </summary>
        /// <returns>`true` if the user has an active subscription, `false` otherwise.</returns>
        public static bool HasActiveSubscription() => _sdk.HasActiveSubscription();

        /// <summary>
        /// Checks if the current user has purchased a specific in-app product.
        /// Returns `false` if the product is refunded or never purchased.
        /// Note: This method considers the most recent purchase of the given product identifier.
        /// </summary>
        /// <param name="productId">The identifier of the product to check.</param>
        /// <returns>`true` if the product is active, `false` otherwise.</returns>
        public static bool IsNonRenewingPurchaseActive(string productId) => _sdk.IsNonRenewingPurchaseActive(productId);

        /// <summary>
        /// Enables debug logs. It is recommended to call this method before SDK initialization.
        /// </summary>
        public static void EnableDebugLogs() => _sdk.EnableDebugLogs();

#if UNITY_ANDROID
        /// <summary>
        /// Refreshes current user data, which includes:
        /// paywalls, placements, subscriptions, non-renewing purchases, or promotionals.
        /// 
        /// __NOTE__: Do not call this method on app launch, as Apphud SDK does it automatically.
        /// 
        /// You can call this method, when the app reactivates from the background, if needed.
        /// </summary>
        public static void RefreshUserData(Action<ApphudUser> callback) => _sdk.RefreshUserData(callback);

        /// <summary>
        /// Collects device identifiers required for some third-party integrations (e.g., AppsFlyer, Adjust, Singular).
        /// Identifiers include Advertising ID, Android ID, App Set ID.
        /// Warning: When targeting Android 13 and above, declare the AD_ID permission in the manifest.
        /// Be sure `optOutOfTracking()` is not called before this, otherwise identifiers will not be collected.
        /// </summary>
        public static void CollectDeviceIdentifiers() => _sdk.CollectDeviceIdentifiers();

        /// <summary>
        /// Returns `true` if fallback mode is on.
        /// That means paywalls are loaded from the fallback json file.
        /// </summary>
        public static bool IsFallbackMode() => _sdk.IsFallbackMode();

        /// <summary>
        /// Tracks a purchase made through Google Play. This method should be used only in Observer Mode,
        /// specifically when utilizing Apphud Paywalls and Placements, and when you need to associate the
        /// purchase with specific paywall and placement identifiers.
        /// 
        /// In all other cases, purchases will be automatically intercepted and sent to Apphud.
        /// 
        /// Note: The `offerIdToken` is mandatory for subscriptions. The `paywallIdentifier` and `placementIdentifier`
        /// are optional but recommended for A/B test analysis in Observer Mode.
        /// </summary>
        /// <param name="productID">The Google Play product ID of the item to purchase.</param>
        /// <param name="offerIdToken">The identifier of the subscription's offer token. This parameter is required for subscriptions.</param>
        /// <param name="paywallIdentifier">(Optional) The identifier of the paywall.</param>
        /// <param name="placementIdentifier">(Optional) The identifier of the placement.</param>
        public static void TrackPurchase(string productID, string offerIdToken = null, string paywallIdentifier = null, string placementIdentifier = null) => _sdk.TrackPurchase(productID, offerIdToken, paywallIdentifier, placementIdentifier);

#elif UNITY_IOS
        /// <summary>
        /// Submits attribution data to Apphud from Apple Search Ads.
        /// For more details, visit https://docs.apphud.com/docs/apple-search-ads
        /// </summary>
        /// <param name="callback">Optional. A closure that returns `true` if the data was successfully sent to Apphud.</param>
        public static void TrackAppleSearchAds() => _sdk.TrackAppleSearchAds();

        /// <summary>
        /// Notifies Apphud when a purchase process is initiated from a paywall in `Observer Mode`, enabling the use of A/B experiments.
        /// This method should be called right before executing your own purchase method, and it's specifically required only when the SDK is in Observer Mode.
        /// </summary>
        /// <param name="paywallIdentifier">Required. The Paywall ID from Apphud Product Hub > Paywalls.</param>
        /// <param name="placementIdentifier"> Optional. The Placement ID from Apphud Product Hub > Placements if using placements; otherwise, pass `nil`.</param>
        public static void WillPurchaseProductFrom(string paywallIdentifier, string placementIdentifier) => _sdk.WillPurchaseProductFrom(paywallIdentifier, placementIdentifier);

        /// <summary>
        /// Submits Device Identifiers (IDFA and IDFV) to Apphud. These identifiers may be required for marketing and attribution platforms such as AppsFlyer, Facebook, Singular, etc.
        /// Best practice is to call this method right after SDK's `start(...)` method and once again after getting IDFA.
        /// </summary>
        /// <param name="idfa">
        /// IDFA. Identifier for Advertisers.
        /// If you request IDFA using App Tracking Transparency framework, you can call this method again after granting access.
        /// You can get it from: [UnityEngine.iOS.Device.advertisingIdentifier]
        /// For more details, visit https://docs.unity.com/ads/en-us/manual/ATTCompliance
        /// </param>
        /// <param name="idfv">
        /// IDFV. Identifier for Vendor.
        /// Can be passed right after SDK's `start` method.
        /// You can get it from: [UnityEngine.iOS.Device.vendorIdentifier]
        /// For more details, visit https://docs.unity.com/ads/en-us/manual/ATTCompliance
        /// </param>
        public static void SetDeviceIdentifiers(string idfa, string idfv) => _sdk.SetDeviceIdentifiers(idfa, idfv);

        /// <summary>
        /// Submits the device's push token to Apphud as a String. This method provides an alternative way to submit the token if you have it in a string format.
        /// </summary>
        /// <param name="str">The push token as a String object.</param>
        /// <param name="callback">An optional closure that returns `true` if the token was successfully sent to Apphud.</param>
        public static void SubmitPushNotificationsTokenString(string str, Action<bool> callback) => _sdk.SubmitPushNotificationsTokenString(str, callback);
#endif

        /// <summary>
        /// Must be called before SDK initialization. If called, certain user parameters
        /// like Advertising ID, Android ID, App Set ID, Device Type, IP address will not be tracked by Apphud.
        /// 
        /// __NOTE__: Consider the privacy implications and ensure compliance
        /// with relevant data protection regulations when opting users out of tracking.
        /// </summary>
        public static void OptOutOfTracking() => _sdk.OptOutOfTracking();

        /// <summary>
        /// Sets a custom user property. The value must be one of the following types:
        /// "int", "float", "double", "bool", "string", or "null".
        /// 
        /// Example:
        /// ApphudSDK.SetUserProperty(ApphudUserPropertyKey.Email, "user@example.com", true);
        /// ApphudSDK.SetUserProperty(ApphudUserPropertyKey.CustomProperty("custom_key"), 0.2f, false);
        /// 
        /// Note: Built-in keys have predefined value types:
        /// "ApphudUserPropertyKey.Email": User email. Value must be String.
        /// "ApphudUserPropertyKey.Name": User name. Value must be String.
        /// "ApphudUserPropertyKey.Phone": User phone number. Value must be String.
        /// "ApphudUserPropertyKey.Age": User age. Value must be Int.
        /// "ApphudUserPropertyKey.Gender": User gender. Value must be one of: "male", "female", "other".
        ///  "ApphudUserPropertyKey.Cohort": User install cohort. Value must be String.
        /// </summary>
        /// <param name="key">The property key, either custom or built-in.</param>
        /// <param name="value">The property value, or "null" to remove the property.</param>
        /// <param name="setOnce">If set to "true", the property cannot be updated later.</param>
        public static void SetUserProperty(ApphudUserPropertyKey key, object value, bool setOnce = false) => _sdk.SetUserProperty(key, value, setOnce);

        /// <summary>
        /// Increments a custom user property. The value to increment must be one of the types:
        /// "int", "float", or "double".
        /// 
        /// Example:
        /// ApphudSDK.IncrementUserProperty(ApphudUserPropertyKey.CustomProperty("custom_key"), 2);
        /// </summary>
        /// <param name="key">The property key, which should be a custom key.</param>
        /// <param name="by">The value to increment the property by. Negative values will decrement.</param>
        public static void IncrementUserProperty(ApphudUserPropertyKey key, object by) => _sdk.IncrementUserProperty(key, by);

        /// <summary>
        /// Submits attribution data to Apphud.
        ///
        /// Note: Properly setting up attribution data is key for tracking and optimizing user acquisition
        /// strategies and measuring the ROI of marketing campaigns.
        /// </summary>
        /// <param name="provider">Required. The name of the attribution provider.</param>
        /// <param name="data">
        /// [iOS] Optional. The `ApphudAttributionData` model. Pass `null` for some integrations
        /// such as Apple Search Ads, Firebase.
        /// [Android] Required. Class with attribution dictionary and custom data.
        /// </param>
        /// <param name="identifier">Optional. An identifier that matches between Apphud and the Attribution provider.</param>
        /// <param name="callback">
        /// Optional. A closure called when the attribution request finishes.
        /// The first parameter indicates whether the data was successfully sent to Apphud.
        /// The second parameter contains the attribution payload returned by Apphud, if available.
        /// The payload may include the following keys: `device_id`, `attribution`, `raw_data`, `provider`.
        ///
        /// [Android] No native callback is available; the closure is invoked synchronously with `(true, null)` after dispatch.
        /// </param>
        public static void SetAttribution(ApphudAttributionProvider provider, ApphudAttributionData data = null, string identifier = null, Action<bool, Dictionary<string, object>> callback = null) => _sdk.SetAttribution(provider, data, identifier, callback);

        /// <summary>
        /// Web-to-Web flow only. Attempts to attribute the user with the provided attribution data.
        /// If the `data` parameter contains either `aph_user_id` or `apphud_user_id`, `email` or `apphud_user_email`, the SDK will submit this information to the Apphud server.
        /// The server will return a restored web user if found; otherwise, the callback will return `false`.
        /// __IMPORTANT:__ If the callback returns `true`, it doesn't mean the user has premium access, you should still call `Apphud.hasPremiumAccess()`
        /// Additionally, the delegate methods `apphudSubscriptionsUpdated` and `apphudDidChangeUserID` may be called.
        /// The callback returns `true` if the user is successfully attributed via the web and includes the updated `ApphudUser` object.
        /// After receiving the callback, you can use the `ApphudSDK.HasPremiumAccess()` method to check if the user has premium access, which will return `true` if the user has premium access.
        /// </summary>
        /// <param name="data">A map containing the attribution data.</param>
        /// <param name="callback">Returns a boolean indicating whether the web attribution was successful, along with the updated `ApphudUser` object (if applicable).</param>
        public static void AttributeFromWeb(Dictionary<string, object> data, Action<bool, ApphudUser> callback) => _sdk.AttributeFromWeb(data, callback);
#if APPHUD_FB
        /// <summary>
        /// Submits attribution data to Apphud from Facebook SDK.
        /// For more details, visit https://docs.apphud.com/docs/facebook-conversions-api
        /// </summary>
        /// <param name="callback">Optional. A callback that returns error message if the data was not successfully sent to Apphud.</param>
        public static void AddFacebookAttribution(Action<string> callback) => _sdk.AddFacebookAttribution(callback);
#endif
        /// <summary>
        /// Explicitly loads fallback paywalls from the json file, if it was added to the project resources.
        /// By default, SDK automatically tries to load paywalls from the JSON file, if possible.
        /// However, developer can also call this method directly for more control.
        /// For more details, visit https://docs.apphud.com/docs/paywalls#set-up-fallback-mode
        /// </summary>
        /// <param name="callback">
        /// The callback function that is invoked with the list of `ApphudPlacement` objects.
        /// Second parameter in callback represents optional error, which may be on Google (BillingClient issue) or Appstore (StoreKit Error) or Apphud side.
        /// </param>
        public static void LoadFallbackPaywalls(Action<List<ApphudPaywall>, ApphudError> callback) => _sdk.LoadFallbackPaywalls(callback);

        /// <summary>
        ///  Must be called before SDK initialization.
        ///  Will make SDK to disregard cache and force refresh paywalls and placements.
        ///  Call it only if keeping paywalls and placements up to date is critical for your app business.
        /// </summary>
        public static void InvalidatePaywallsCache() => _sdk.InvalidatePaywallsCache();
    }
}
